## Connect to Postgresql Database

Add Postgresql database connection details in `server/db/connect.js` file

## Add database tables

Execute sql scripts from `server/scripts.sql` file

## To run the project execute following commands in sequence

    1. cd server
    2. yarn install
    3. yarn start
    4. cd ..
    5. yarn install
    6. yarn start

## Available Scripts

In the project directory, you can run:

### `yarn start`

Runs the app in the development mode.<br />
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.

### `yarn build`

Builds the app for production to the `build` folder.<br />
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.<br />
the app is ready to be deployed!

